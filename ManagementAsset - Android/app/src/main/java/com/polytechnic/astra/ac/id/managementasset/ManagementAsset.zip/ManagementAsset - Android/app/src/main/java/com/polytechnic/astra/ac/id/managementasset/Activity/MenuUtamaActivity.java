package com.polytechnic.astra.ac.id.managementasset.Activity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.polytechnic.astra.ac.id.managementasset.R;

public class MenuUtamaActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_menuawal);
    }
}
